package ro.usv.rf;

public class DistanceUtils {
	 public static double  calculateEuclidianDistance(String []trainingSet,String p2[],int noOfF) {

	        double suma=0.0;
	        for(int i=0;i<noOfF;i++)
	        {
	            suma = Math.pow(Double.valueOf(trainingSet[i])-Double.valueOf(p2[i]),2)  ;
	        }

	        return Math.sqrt(suma);
	    }

	    public static double []calculateEuclidianDistanceMatrice(String [][]learningSet, String[][] trainingSet)
	    {
	        double  []mat = new double [learningSet.length];
	        for(int i=0;i<learningSet.length;i++)
	        {
	                mat[i]=calculateEuclidianDistance(trainingSet[i],learningSet[i],2);
	        }
	        return mat;
	    }
}
