package ro.usv.rf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


public class MainClass {

	public static void main(String[] args) {
		String[][] learningSet;
		try {
			learningSet = FileUtils.readLearningSetFromFile("iris.csv");
			int numberOfPatterns = learningSet.length;
			int numberOfFeatures = learningSet[0].length-1;

			System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns,
					numberOfFeatures));
			
			Map<String, Integer> classesMap = new HashMap<String, Integer>();
			
			//create map with distinct classes and number of occurence for each class
			for (int i=0; i<numberOfPatterns; i++)
			{
				String clazz = learningSet[i][learningSet[i].length-1];
				if (classesMap.containsKey(clazz))
				{
					Integer nrOfClassPatterns = classesMap.get(clazz);
					classesMap.put(clazz, nrOfClassPatterns + 1);
				}
				else
				{
					classesMap.put(clazz, 1);
				}
			}
			System.out.println(String.format(" Avem %s", classesMap));
			
			Random random = new Random();
			//map that keeps for each class the random patterns selected for evaluation set
			Map<String, List<Integer>> classesEvaluationPatterns = new HashMap<String, List<Integer>>();
			Integer evaluationSetSize = 0;
			for (Map.Entry<String, Integer> entry: classesMap.entrySet())
			{
				String className = entry.getKey(); // scoate denumirele 
				Integer classMembers = entry.getValue();// scoate valorile 
				Integer evaluationPatternsNr = Math.round(classMembers *15/100); //rezultatul cu o floare 
				evaluationSetSize += evaluationPatternsNr; // aduna toate rezultatele 
				List<Integer> selectedPatternsForEvaluation = new ArrayList<Integer>();
				for (int i=0; i<evaluationPatternsNr; i++) // repeta de 10%
				{
					Integer patternNr = random.nextInt(classMembers ) +1;//interval[0,49], aducem un nr de forme, a cata forma a fost aleasa pt clasa curenta
					while (selectedPatternsForEvaluation.contains(patternNr))
					{
						patternNr = random.nextInt(classMembers ) +1;
					}
					selectedPatternsForEvaluation.add(patternNr); //adauga in lista formele ce nu sunt alese
				}
				classesEvaluationPatterns.put(className, selectedPatternsForEvaluation);				
			}
			//construim cele 2 seturi de invatare si de evaluare
			String[][] evaluationSet = new String[evaluationSetSize][numberOfPatterns];
			String[][] trainingSet = new String[numberOfPatterns-evaluationSetSize][numberOfPatterns];
			int evaluationSetIndex = 0;
			int trainingSetIndex = 0;
			Map<String, Integer> classCurrentIndex = new HashMap<String, Integer>();
			for (int i=0; i<numberOfPatterns; i++)
			{
				String className = learningSet[i][numberOfFeatures];//ultima coloana
				if (classCurrentIndex.containsKey(className))
				{
					int currentIndex = classCurrentIndex.get(className);
					classCurrentIndex.put(className, currentIndex+1);
				}
				else
				{
					classCurrentIndex.put(className, 1);//prima data cand intalnim o floare din clasa respectiva
				}
				if (classesEvaluationPatterns.get(className).contains(classCurrentIndex.get(className)))//lista cu formele selectate contine indexul formei noastre la clasa care suntem
				{
					evaluationSet[evaluationSetIndex] = learningSet[i];
					evaluationSetIndex++;
				}
				else
				{
					trainingSet[trainingSetIndex] = learningSet[i];
					trainingSetIndex++;
				}
			}
			FileUtils.writeLearningSetToFile("eval.txt", evaluationSet);
			FileUtils.writeLearningSetToFile("train.txt", trainingSet);
			
			double[] m = DistanceUtils.calculateEuclidianDistanceMatrice(evaluationSet,trainingSet);
            //Arrays.sort(m);
            for(int i=0;i<learningSet.length;i++)
            {
                    System.out.println(m[i]+" "); // afiseaza toate distantele intre orasul nostru si celelalte
            }
            System.out.println("..........................................");
            System.out.println("Primele 9 flori sunt:");
            for(int i=0;i<9;i++)
            {

                System.out.println(m[i]+" ");

            }
			
		} catch (USVInputFileCustomException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Finished learning set operations");
		}
	}

}
