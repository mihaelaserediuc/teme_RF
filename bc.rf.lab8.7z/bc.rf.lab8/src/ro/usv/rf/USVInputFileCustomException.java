package ro.usv.rf;

public class USVInputFileCustomException extends Exception {

	private static final long serialVersionUID = 1L;
	
    public USVInputFileCustomException(String message) {
        super(message);
    }

}